miles_per_gallon =float(input())
dollars_per_gallon= float(input())
dollars_per_miles=dollars_per_gallon/miles_per_gallon
your_value1= 20*dollars_per_miles
your_value2 =75 *dollars_per_miles
your_value3= 500 *dollars_per_miles
print(f'{your_value1:.2f} {your_value2:.2f} {your_value3:.2f}')  

