num1 = float(input())
num2 = float(input())
num3 = float(input())
num4 = float(input())
product_all=num1*num2*num3*num4
sum_all=num1+num2+num3+num4
product=num1*num2*num3*num4
average= (num1+num2+num3+num4)/4
''' Type your code here. '''
print (f'{product:.0f} {average:.0f}')
print (f'{product:.3f} {average:.3f}')